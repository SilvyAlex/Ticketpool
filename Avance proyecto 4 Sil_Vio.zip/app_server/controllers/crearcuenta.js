//homepage - GET
const crearcuenta = (req, res, next) => {
    res.render('crearcuenta', {title: 'Usuarios'});
}

module.exports = {
    crearcuenta //Index - GET
    
}